import re, json
from google.cloud import storage
import PyPDF2
 
def readFromBucket(file_name, bucket):
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket)
    blob = bucket.blob(file_name)
    return blob
 
def readFromLocalPDF(local_path):
    with open(local_path, "rb") as file:
        image_content = file.read()
    return image_content

# read from pdf using PyPDF2 instead of using ocr - temp solution
def readPDF(local_path):
    with open(local_path, 'rb') as file:
        # Create a PDF reader object
        pdf_reader = PyPDF2.PdfReader(file)

        # Extract text from all pages and concatenate
        all_text = ""
        for page in pdf_reader.pages:
            all_text += page.extract_text()
    return all_text
 
def read_md_file(filepath: str) -> str:
    with open(filepath, 'r', encoding='utf-8') as file:
        file_content = file.read()
    return file_content
 
 
def clean_json(llm_result: str) -> str:
    """
    openai has a tendency to change add these symbols to the results, remove them before populating
    final json
    """
    llm_result = llm_result.replace("```json", "")
    llm_result = llm_result.replace("```python", "")
    llm_result = llm_result.replace("```", "")
    llm_result = llm_result.replace("\n", "")
    # extra for hebrew " in words
    pattern = r'(?<=[\u0590-\u05FF])"(?=[\u0590-\u05FF])'
    llm_result = re.sub(pattern, "''", llm_result)
    return llm_result
 
 
def verify_json(openai_result):
    try:
        if isinstance(openai_result, dict):
            # Already a dictionary, no need to parse it
            return openai_result
        else:
            json_data = json.loads(openai_result)
            return json_data
    except json.JSONDecodeError as e:
        print(f"Error with JSON {openai_result}: {e}")
        return {}
 
 
def is_pdf(file_path):
    try:
        with open(file_path, 'rb') as file:
            header = file.read(4)
            return header == b'%PDF'
    except FileNotFoundError:
        print("File not found.")
        return False