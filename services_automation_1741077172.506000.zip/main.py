import functions_framework
import os, json
from google.api_core.client_options import ClientOptions
from google.cloud import bigquery
from google.cloud import documentai
from google.cloud import storage
from google.cloud import firestore
import vertexai
from vertexai.preview.generative_models import GenerativeModel, Image
from utilities import *
from PIL import Image
 
 
def create_result_base(filename, status_code="200", status_description="success"):
    # Split the filename by underscores

    filename = os.path.splitext(filename)[0]
    parts = filename.split('_')


    # Convert parts into required data types and build the JSON structure
    result = {
        "dataResult": {
            "assistanceFileId": parts[1],
            "documentAccuracy": 0.0,  # Default number
            "documentId": parts[0],
            "documentType": parts[2],
            "yearlyData": [
                {
                    "data": [
                        {
                            "accuracy": None,
                            "amount": None,
                            "familyComposition": "",
                            "healthInsuranceDeduction": "",
                            "month": None
                        }
                    ],
                    "year": None
                }
            ]
        },
        "filename": filename,
        "status_description": status_description,
        "status_code": status_code
    }
 
    return result
 
PROJECT_ID = 'dgt-gcp-cgov-d-datapro'
location = 'eu'
mime_type = 'application/pdf'
processor_id = '5e730998490459b'
 
def parseOCR(image_content):
    opts = ClientOptions(api_endpoint=f"{location}-documentai.googleapis.com")
    client = documentai.DocumentProcessorServiceClient(client_options=opts)
    name = client.processor_path(PROJECT_ID, location, processor_id)
 
    raw_document = documentai.RawDocument(content=image_content, mime_type=mime_type)
    request = documentai.ProcessRequest(name=name, raw_document=raw_document)
    result = client.process_document(request=request)
    document = result.document
   
    return document
 
MODEL_ID="gemini-1.5-pro-002"
REGION = "us-central1"

 
def parseGemini(extracted_text):
    vertexai.init(project=PROJECT_ID, location=REGION)
    model = GenerativeModel("gemini-1.5-pro-002")
 
    prompt = read_md_file('IncomeSupport.md')
    response = model.generate_content([prompt, extracted_text])
   
    return response
 

PROJECT_NAME = "dgt-gcp-cgov-d-datapro"

db = firestore.Client(project=PROJECT_NAME, database="firestore-binom")
 
def write_to_firestore(data, collection_name):
    # Specify the Firestore collection
    collection_ref = db.collection(collection_name)
   
    # Add each entry in the JSON schema as a document in Firestore
    for doc in data:
        # Use `doc_id` as the document ID in Firestore, if you have one; otherwise, use `add`
        collection_ref.document(doc['filename']).set(doc)
       
    print(f"Added {len(data)} documents to Firestore collection '{collection_name}'")
 
 
def validateSize(local_path):
    file_size = os.path.getsize(local_path)
    if file_size > 2 * 1024 * 1024:
        print("Error: File size exceeds 2MB.")
        return False
    return True
 
 
def validateFileName(file_name):
    # Define the filename pattern
    # pattern = r'^[a-zA-Z0-9]+_\d+_\d+_\d+_\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\.pdf$'
    pattern = r'^\d+_\d+_\d+_\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\.pdf$'
 
   
    # Check filename format
    filename = os.path.basename(file_name)
    if not re.match(pattern, filename):
        print("Error: Filename format is incorrect.")
        return False
    return True
 
# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def hello_gcs(cloud_event):
    file = cloud_event.data
 
    print("before read from bucket")
 
    # read from bucket
    blob = readFromBucket(file['name'], file['bucket'])
 
    print("after read from bucket")
    
    # take only file name without relative path on bucket
    file_name = file['name'].split("/")[-1]
    print(file_name)

    # save to local tmp file
    local_path = "/tmp/" + file_name
    blob.download_to_filename(local_path)
 
    # check if file is .png or .jpg .jpeg convert image file type to PDF
    if file_name.lower().endswith(('.jpeg', '.png', '.jpg', '.pdf')):
        if not file_name.lower().endswith('.pdf'):
            print("The file is not a PDF based on the extension, converting to PDF")
            image = Image.open(local_path)
            local_path = local_path.replace(".png", ".pdf").replace(".jpg", ".pdf").replace(".jpeg", ".pdf")
            image.save(local_path)
 
        print("The file is a PDF based on the extension.")
        print("continue to more validations...")

        # validate file_name (identifier) and file size
        if not validateSize(local_path):
            print("break because of file size")
            data = create_result_base(file_name, status_code="413", status_description="The provided ID didn't pass validation phase - size")
            print(data)
            collection_name = 'results'
            write_to_firestore([data], collection_name)
            return

        if not validateFileName(file['name']):
            print("break because of file naming")
            data = create_result_base(file_name, status_code="415", status_description="The provided ID didn't pass validation phase - file name")
            print(data)
            collection_name = 'results'
            write_to_firestore([data], collection_name)
            return

        print(f"Passed all validationsm start processing file: {file_name}.")
 
        # read local file
        from utilities import readFromLocalPDF
        
        image_content = readFromLocalPDF(local_path)
 
        # validate pdf based on binary content
        if is_pdf(local_path):
            print("The file is a PDF based on the content.")

            file_name = os.path.splitext(os.path.basename(file['name']))[0]
            # parse OCR
            try:
                document = parseOCR(image_content)
                print("OCR result: " + document.text)
            
                # parse GEMINI - changed document.text to just text
                result = parseGemini(document.text)
                print("LLM result: " + result.text)
            
                # clean result and verify
                clean_result = clean_json(result.text)
                verified_result = verify_json(clean_result)
            
                data = create_result_base(file_name, status_code="200", status_description="success")
                data['dataResult']['yearlyData'] = verified_result['yearlyData']

            except Exception as e:
                print(f"An error occurred: {e}")
                # Handle the error appropriately, e.g., log it, return a default value, etc.
                data = create_result_base(file_name, status_code="204", status_description="unexpected error while processing")

            # save to firestore
            collection_name = 'results'
            write_to_firestore([data], collection_name)
        else:
            print("The file is not a PDF based on the content.")
            data = create_result_base(file_name, status_code="414", status_description="The provided ID didn't pass validation phase - file type")
            collection_name = 'results'
            write_to_firestore([data], collection_name)

    else:
        print("The file is not a PDF based on the extension.")
        data = create_result_base(file_name, status_code="414", status_description="The provided ID didn't pass validation phase - file type")
        collection_name = 'results'
        write_to_firestore([data], collection_name)