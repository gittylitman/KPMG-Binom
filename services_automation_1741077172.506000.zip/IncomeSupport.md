# Task
You are given an Income Support Eligibility Confirmation. and you need to extract some key informations.
                 
# Instructions
The given file contain table for each year divided to rows for each month.
If field value don't exist fill with '' (empty string)
 
the json you need to output is as follows:
"yearlyData" field which is a list of objects, where each object represent a year.
inside each year object we have "data" field which is a list of months of that same year.
 
## Fields to be extracted inside each month
 
- **month**
- description: 'the month of the income payment'
- keywords: 'חודש'
- note: the month is a string representing months in Hebrew
 
- **amount**
- description: 'the amount in NIS of the income payment'
- keywords: 'סכום גמלה'
- note: if amount is valid it contain number with the currency of NIS 'ש"ח', only extract the number. if not, it should present with the string 'לא זכאי' and please extract that too otherwise.
 
- **familyComposition**
- description: 'the family composition of the person getting the income payment'
- keywords: 'הרכב משפחתי'
- note:
 
- **healthInsuranceDeduction**
- description: 'the deduction amount from 'amount' for national insurance'
- keywords: 'ניכוי לביטוח לאומי'
- note: if amount is valid it contain number with the currency of NIS 'ש"ח', only extract the number.
 
 
 
# Result JSON Schema Example 1
"yearlyData": [
{
    "data": [
    {
        "accuracy": "97.5",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "אוקטובר"
    },
    {
        "accuracy": "84.8",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "נובמבר"
    },
    {
        "accuracy": "98.8",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "דצמבר"
    }
    ],
    "year": "2023"
},
{
    "data": [
    {
        "accuracy": "97.5",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "ינואר"
    },
    {
        "accuracy": "84.8",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "פברואר"
    },
    {
        "accuracy": "98.8",
        "amount": "232",
        "familyComposition": "זוג",
        "healthInsuranceDeduction": "-1",
        "month": "מרץ"
    }
    ],
    "year": "2024"
}
]
 
 
# Result JSON Schema Example 2
"yearlyData": [
{
    "data": [
    {
        "accuracy": "97.5",
        "amount": "לא זכאי",
        "familyComposition": "",
        "healthInsuranceDeduction": "",
        "month": "מאי"
    },
    {
        "accuracy": "84.8",
        "amount": "לא זכאי",
        "familyComposition": "",
        "healthInsuranceDeduction": "",
        "month": "יוני"
    },
    {
        "accuracy": "98.8",
        "amount": "לא זכאי",
        "familyComposition": "",
        "healthInsuranceDeduction": "",
        "month": "יולי"
    }
    ],
    "year": "2023"
}
]