import functions_framework
from flask import Flask, request, jsonify
import firebase_admin
from firebase_admin import firestore
import json


db = firestore.Client(project="dgt-gcp-cgov-d-datapro", database="firestore-binom")

def read_from_firestore(id):

    # Reference to the 'results' collection and the specific document by ID
    result_ref = db.collection("results").document(id)

    # Get the document snapshot
    result_doc = result_ref.get()

    # Check if the document exists and return it as a dictionary
    if result_doc.exists:
        return result_doc.to_dict()
    else:
        return {"message": f"Document with ID {id} not found."}

@functions_framework.http
def getResult(request):
   
    ids_args = request.args.get('ids', "")  # Provide an empty string if 'ids' is missing
    ids_args = ids_args.split(",") if ids_args else []

    request_json = request.get_json(silent=True) or {}  # Safe access to prevent errors
    ids_body = request_json.get('ids', [])

    # If no IDs are provided, return an error
    if not ids_args and not ids_body:
        return jsonify({"message": "No IDs provided"}), 400
    elif ids_args:
        ids = ids_args
    else:
        ids = ids_body


    # Process each ID and generate a response
    response_list = []
    for id in ids:
        result = read_from_firestore(id)
        response_list.append(result)
    
    # Return the list of responses for each ID
    return jsonify(response_list), 200
